export default async function registerDomain(req, res) {
  res.end('')
}
