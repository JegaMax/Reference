import LandingPage from '../landing'

export default function Home() {
  return <LandingPage />
}
