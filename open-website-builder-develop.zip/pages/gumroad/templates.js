import GumroadTemplatePage from '../../components/gumroad-template-page'

export default function Templates() {
  return <GumroadTemplatePage />
}
