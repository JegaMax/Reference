import TemplatePage from '../components/template-page'

export default function Templates() {
  return <TemplatePage />
}
