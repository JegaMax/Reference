import ErrorPage from '../components/error-page'

export default function Error() {
  return <ErrorPage />
}
