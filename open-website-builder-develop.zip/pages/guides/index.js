import GuidesPage from '../../components/guides'

const Guides = () => {
  return <GuidesPage />
}

export default Guides
