import newSubscriberEmail from './newSubscriberEmail'

export default {
  newSubscriberEmail,
}
