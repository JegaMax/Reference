## Antfolio

This project is a website builder. The pros are the freedom you have to create while mainting simplicity (easy-to-use).

It started out as a side project but now it has become an open-source with a non-profit purpose. (Right now unmaintained)

The project pivoted from a resume builder (to help candidates outstand from the crowd by offering a more visual resume that would encourage recruiters to read it) to a website builder online for any kind of purpose like a personal (portfolio) website, a website to sell your online products or to attract people to your gumroad, an event/party/invitation website, wedding invitations, etc. 

It is still a wip but it has already reached the MVP.



<img width="1012" alt="Screenshot 2022-08-27 at 20 34 40" src="https://user-images.githubusercontent.com/44972334/187043700-b2b9a243-d1a0-459b-b3e3-0f6f65b51334.png">

## Examples

<img width="512" alt="Screenshot 2022-08-27 at 20 35 17" src="https://user-images.githubusercontent.com/44972334/187043724-32e3fd6f-3f5e-46b8-90a1-e05c8160ba4e.png">

## Builder

<img width="512" alt="Screenshot 2022-08-27 at 20 35 33" src="https://user-images.githubusercontent.com/44972334/187043732-d9b8e04f-6b17-4e96-98c8-7ae5b252016f.png">

## RayCasting

![Screenshot 2022-08-28 at 10 33 15 (2)](https://user-images.githubusercontent.com/44972334/187065329-56443287-61fb-4d13-b4f8-e88012fce2ad.png)

## Installation

- cd project
- yarn
- yarn dev
