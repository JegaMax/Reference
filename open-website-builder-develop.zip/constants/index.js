export const BUSINESS = 'business'
export const PRO = 'pro'
