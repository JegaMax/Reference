export const GRID_COLUMNS = 200
export const ROW_HEIGHT = 10
export const STANDARD_MOBILE_SIZE = 375
