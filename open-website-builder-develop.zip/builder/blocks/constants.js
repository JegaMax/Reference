export const DELETE = 'delete'
export const EDIT = 'edit'
export const DUPLICATE = 'duplicate'
