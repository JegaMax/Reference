export { default } from './new-page'
