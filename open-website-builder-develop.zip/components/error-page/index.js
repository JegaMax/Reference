export { default } from './error-page'
