export { default } from './templates-page'
