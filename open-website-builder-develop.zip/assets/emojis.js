import Dribble from './dribble-icon'

export const emojis = [
  {
    value: '😄',
  },
  {
    value: '😎',
  },
  {
    value: '😊',
  },
  {
    value: '😋',
  },
  {
    value: '👋',
  },
  {
    value: '💪',
  },
  {
    value: '🙌',
  },
  {
    value: '✌',
  },
  {
    value: '👌',
  },
  {
    value: '💼',
  },
  {
    value: '🎓',
  },
  {
    value: '🎉',
  },

  {
    value: '🚀',
  },
  {
    value: '🌟',
  },

  {
    value: '❤',
  },
  {
    value: '✨',
  },

  {
    value: '🌏',
  },
  {
    value: '✍',
  },
  {
    value: '🎨',
  },
  {
    value: '✅',
  },
  {
    value: 'Ⓡ',
  },
  {
    value: '🎶',
  },
  {
    value: '⛷',
  },
  {
    value: '🏂',
  },
  {
    value: '❄',
  },
  {
    value: '🎸',
  },
  {
    value: '🏆',
  },
  {
    value: '🏀',
  },
  // {
  //   value: <Dribble />,
  // },
]
