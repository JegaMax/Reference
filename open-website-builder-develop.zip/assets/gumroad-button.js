const GumroadIcon = () => {
  return (
    <img src="/gumroad.png" style={{ height: '60%', objectFit: 'contain' }} />
  )
}

export default GumroadIcon
